# KAWSAR E-commerce Site Deployment Guide

This guide will help you deploy the KAWSAR e-commerce application on a new hosting provider.

## Project Overview

KAWSAR is a full-stack e-commerce application built with:
- React frontend
- Express backend
- PostgreSQL database
- TypeScript throughout

## Files Included

Two zip files have been created for you:
1. `kawsar-ecommerce.zip` - Complete project including all files
2. `kawsar-essential.zip` - Only essential files needed for deployment

## Deployment Steps

### 1. Prerequisites

You'll need the following installed on your hosting server:
- Node.js (v16 or higher)
- PostgreSQL database
- npm or yarn

### 2. Database Setup

1. Create a new PostgreSQL database for the project
2. Note the database connection details:
   - Database URL string (or host, port, username, password, database name)

### 3. Project Setup

1. Upload and extract either `kawsar-ecommerce.zip` or `kawsar-essential.zip` to your server
2. Navigate to the project directory
3. Install dependencies:
   ```
   npm install
   ```
4. Create a `.env` file in the project root with your database connection info:
   ```
   DATABASE_URL=postgresql://username:password@host:port/database
   ```

### 4. Database Schema and Seeding

1. Push the database schema:
   ```
   npx drizzle-kit push
   ```
2. Seed the database with initial data:
   ```
   npx tsx server/db-seed.ts
   ```

### 5. Building for Production

1. Build the project:
   ```
   npm run build
   ```

### 6. Starting the Server

1. Start in production mode:
   ```
   npm run start
   ```
   Or use a process manager like PM2:
   ```
   pm2 start npm --name "kawsar" -- run start
   ```

### 7. Configuring Reverse Proxy (Optional)

If you're using Nginx or Apache, set up a reverse proxy to forward requests to your Node.js application.

Example Nginx configuration:
```
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Additional Notes

- The application uses port 5000 by default
- The database connection string should follow the format: `postgresql://username:password@host:port/database`
- If you want to change the port, modify the `server/index.ts` file

## Troubleshooting

Common issues:
1. Database connection errors - Check your DATABASE_URL environment variable
2. Port already in use - Change the port in server/index.ts
3. Missing dependencies - Make sure you ran `npm install`
4. Build errors - Ensure all dependencies are installed correctly