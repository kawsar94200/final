import { 
  type Category, 
  type InsertCategory, 
  type Product, 
  type InsertProduct,
  type Banner,
  type InsertBanner,
  type CartItem,
  type InsertCartItem,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem
} from "@shared/schema";
import { db } from './db';
import { eq, and, or, inArray, ilike } from 'drizzle-orm';
import * as schema from '@shared/schema';

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;

  // Products
  getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    flashDeal?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  searchProducts(query: string): Promise<Product[]>;
  getProductsByIds(ids: number[]): Promise<Product[]>;

  // Banners
  getBanners(): Promise<Banner[]>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItem[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  createCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;

  // Orders
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersBySessionId(sessionId: string): Promise<Order[]>;
}

export class MemStorage implements IStorage {
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private banners: Map<number, Banner>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  
  private categoryId: number;
  private productId: number;
  private bannerId: number;
  private cartItemId: number;
  private orderId: number;
  private orderItemId: number;

  constructor() {
    this.categories = new Map();
    this.products = new Map();
    this.banners = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    
    this.categoryId = 1;
    this.productId = 1;
    this.bannerId = 1;
    this.cartItemId = 1;
    this.orderId = 1;
    this.orderItemId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // Initialize with sample data
  private initializeData() {
    // Add sample categories
    const categories = [
      { name: "Smartphones", slug: "smartphones", icon: "fa-mobile-screen-button" },
      { name: "Laptops", slug: "laptops", icon: "fa-laptop" },
      { name: "TVs", slug: "tvs", icon: "fa-tv" },
      { name: "Men's Fashion", slug: "mens-fashion", icon: "fa-shirt" },
      { name: "Women's Fashion", slug: "womens-fashion", icon: "fa-shirt" },
      { name: "Home Appliances", slug: "home-appliances", icon: "fa-house" },
    ];
    
    categories.forEach(cat => {
      const category = { 
        id: this.categoryId++, 
        ...cat 
      };
      this.categories.set(category.id, category);
    });

    // Add sample products
    const products = [
      {
        name: "Samsung Galaxy S21 Ultra 5G",
        slug: "samsung-galaxy-s21-ultra-5g",
        description: "Experience the power of Samsung's flagship smartphone with an extraordinary camera and display.",
        price: 48999,
        originalPrice: 56000,
        discountPercentage: 13,
        image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 4.5,
        reviewCount: 432,
        stock: 50,
        featured: true,
        flashDeal: true
      },
      {
        name: "Apple Watch Series 7 GPS 41mm",
        slug: "apple-watch-series-7-gps-41mm",
        description: "The future of health is on your wrist with sensors that track all the ways you move.",
        price: 32500,
        originalPrice: 42000,
        discountPercentage: 23,
        image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 5.0,
        reviewCount: 185,
        stock: 35,
        featured: false,
        flashDeal: true
      },
      {
        name: "Wireless Bluetooth Earbuds with Charging Case",
        slug: "wireless-bluetooth-earbuds",
        description: "True wireless earbuds with high-quality sound and long battery life.",
        price: 1899,
        originalPrice: 3500,
        discountPercentage: 46,
        image: "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 4.0,
        reviewCount: 356,
        stock: 100,
        featured: false,
        flashDeal: true
      },
      {
        name: "Nike Air Zoom Running Shoes for Men",
        slug: "nike-air-zoom-running-shoes",
        description: "Premium running shoes designed for comfort and performance.",
        price: 5999,
        originalPrice: 8500,
        discountPercentage: 29,
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 4,
        rating: 3.5,
        reviewCount: 129,
        stock: 75,
        featured: false,
        flashDeal: true
      },
      {
        name: "MacBook Pro 14-inch M2 Chip 16GB RAM",
        slug: "macbook-pro-14-inch-m2",
        description: "The ultimate pro laptop with incredible performance and battery life.",
        price: 199999,
        originalPrice: 199999,
        discountPercentage: 0,
        image: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 2,
        rating: 4.5,
        reviewCount: 78,
        stock: 10,
        featured: true,
        flashDeal: false
      },
      {
        name: "Noise-Cancelling Wireless Headphones",
        slug: "noise-cancelling-wireless-headphones",
        description: "Premium headphones with exceptional sound quality and noise cancellation.",
        price: 9999,
        originalPrice: 14500,
        discountPercentage: 31,
        image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 4.0,
        reviewCount: 254,
        stock: 30,
        featured: true,
        flashDeal: false
      },
      {
        name: "Smart Fitness Watch with Heart Rate Monitor",
        slug: "smart-fitness-watch",
        description: "Track your fitness goals with this advanced smart watch.",
        price: 3499,
        originalPrice: 4999,
        discountPercentage: 30,
        image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 5.0,
        reviewCount: 432,
        stock: 45,
        featured: true,
        flashDeal: false
      },
      {
        name: "Luxury Leather Phone Case for iPhone 14 Pro",
        slug: "luxury-leather-phone-case-iphone-14",
        description: "Elegant and protective case made from premium leather.",
        price: 1299,
        originalPrice: 1999,
        discountPercentage: 35,
        image: "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
        categoryId: 1,
        rating: 3.5,
        reviewCount: 98,
        stock: 200,
        featured: true,
        flashDeal: false
      }
    ];

    products.forEach(prod => {
      const product = {
        id: this.productId++,
        ...prod
      };
      this.products.set(product.id, product);
    });

    // Add sample banners
    const banners = [
      {
        image: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=300",
        alt: "Smartphone Promotion",
        url: "/category/smartphones",
        active: true,
        order: 1
      },
      {
        image: "https://images.unsplash.com/photo-1607083206968-13611e3d76db?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=300",
        alt: "Fashion Sale",
        url: "/category/mens-fashion",
        active: true,
        order: 2
      },
      {
        image: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=300",
        alt: "Electronics Special Offer",
        url: "/category/laptops",
        active: true,
        order: 3
      },
      {
        image: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=300",
        alt: "Home Appliances Discount",
        url: "/category/home-appliances",
        active: true,
        order: 4
      }
    ];

    banners.forEach(ban => {
      const banner = {
        id: this.bannerId++,
        ...ban
      };
      this.banners.set(banner.id, banner);
    });
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug
    );
  }

  // Product methods
  async getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    flashDeal?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    // Filter by category
    if (options?.categoryId) {
      products = products.filter(p => p.categoryId === options.categoryId);
    }
    
    // Filter featured products
    if (options?.featured !== undefined) {
      products = products.filter(p => p.featured === options.featured);
    }
    
    // Filter flash deal products
    if (options?.flashDeal !== undefined) {
      products = products.filter(p => p.flashDeal === options.flashDeal);
    }
    
    // Apply pagination
    if (options?.limit) {
      const offset = options.offset || 0;
      products = products.slice(offset, offset + options.limit);
    }
    
    return products;
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    query = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query)
    );
  }

  async getProductsByIds(ids: number[]): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => ids.includes(product.id)
    );
  }

  // Banner methods
  async getBanners(): Promise<Banner[]> {
    return Array.from(this.banners.values())
      .filter(banner => banner.active)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  // Cart methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );
  }

  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }

  async createCartItem(item: InsertCartItem): Promise<CartItem> {
    // Check if product exists in the cart
    const existingItem = Array.from(this.cartItems.values()).find(
      (ci) => ci.sessionId === item.sessionId && ci.productId === item.productId
    );

    if (existingItem) {
      // Update quantity
      existingItem.quantity += item.quantity || 1;
      return existingItem;
    }

    const cartItem: CartItem = {
      id: this.cartItemId++,
      ...item,
      quantity: item.quantity || 1,
    };
    this.cartItems.set(cartItem.id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) {
      return undefined;
    }

    cartItem.quantity = quantity;
    return cartItem;
  }

  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );
    
    items.forEach(item => {
      this.cartItems.delete(item.id);
    });
    
    return true;
  }

  // Order methods
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const newOrder: Order = {
      id: this.orderId++,
      ...order,
      status: order.status || 'pending',
      createdAt: new Date()
    };
    
    this.orders.set(newOrder.id, newOrder);
    
    // Create order items
    items.forEach(item => {
      const orderItem: OrderItem = {
        id: this.orderItemId++,
        ...item,
        quantity: item.quantity || 1,
        orderId: newOrder.id
      };
      this.orderItems.set(orderItem.id, orderItem);
    });
    
    return newOrder;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersBySessionId(sessionId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.sessionId === sessionId
    );
  }
}

export class DatabaseStorage implements IStorage {
  // Categories
  async getCategories(): Promise<Category[]> {
    const categories = await db.query.categories.findMany();
    return categories;
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const category = await db.query.categories.findFirst({
      where: eq(schema.categories.id, id)
    });
    return category || undefined;
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const category = await db.query.categories.findFirst({
      where: eq(schema.categories.slug, slug)
    });
    return category || undefined;
  }

  // Products
  async getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    flashDeal?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<Product[]> {
    let whereConditions = [];
    
    if (options?.categoryId) {
      whereConditions.push(eq(schema.products.categoryId, options.categoryId));
    }
    
    if (options?.featured !== undefined) {
      whereConditions.push(eq(schema.products.featured, options.featured));
    }
    
    if (options?.flashDeal !== undefined) {
      whereConditions.push(eq(schema.products.flashDeal, options.flashDeal));
    }
    
    let query = {};
    
    if (whereConditions.length > 0) {
      query = { where: and(...whereConditions) };
    }
    
    if (options?.limit) {
      query = { 
        ...query,
        limit: options.limit,
        offset: options.offset || 0
      };
    }
    
    const products = await db.query.products.findMany(query);
    return products;
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const product = await db.query.products.findFirst({
      where: eq(schema.products.id, id)
    });
    return product || undefined;
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const product = await db.query.products.findFirst({
      where: eq(schema.products.slug, slug)
    });
    return product || undefined;
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    
    const products = await db.query.products.findMany({
      where: or(
        ilike(schema.products.name, `%${lowercaseQuery}%`),
        ilike(schema.products.description, `%${lowercaseQuery}%`)
      )
    });
    
    return products;
  }

  async getProductsByIds(ids: number[]): Promise<Product[]> {
    const products = await db.query.products.findMany({
      where: inArray(schema.products.id, ids)
    });
    return products;
  }

  // Banners
  async getBanners(): Promise<Banner[]> {
    const banners = await db.query.banners.findMany({
      where: eq(schema.banners.active, true),
      orderBy: schema.banners.order
    });
    return banners;
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    const cartItems = await db.query.cartItems.findMany({
      where: eq(schema.cartItems.sessionId, sessionId)
    });
    return cartItems;
  }

  async getCartItem(id: number): Promise<CartItem | undefined> {
    const cartItem = await db.query.cartItems.findFirst({
      where: eq(schema.cartItems.id, id)
    });
    return cartItem || undefined;
  }

  async createCartItem(item: InsertCartItem): Promise<CartItem> {
    // Check if product exists in cart
    const existingItem = await db.query.cartItems.findFirst({
      where: and(
        eq(schema.cartItems.sessionId, item.sessionId),
        eq(schema.cartItems.productId, item.productId)
      )
    });
    
    if (existingItem) {
      // Update quantity
      const updatedItem = await db.update(schema.cartItems)
        .set({ quantity: existingItem.quantity + (item.quantity || 1) })
        .where(eq(schema.cartItems.id, existingItem.id))
        .returning();
      return updatedItem[0];
    }
    
    // Create new cart item
    const [cartItem] = await db.insert(schema.cartItems)
      .values({
        ...item,
        quantity: item.quantity || 1
      })
      .returning();
    
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const [updatedItem] = await db.update(schema.cartItems)
      .set({ quantity })
      .where(eq(schema.cartItems.id, id))
      .returning();
    
    return updatedItem;
  }

  async deleteCartItem(id: number): Promise<boolean> {
    await db.delete(schema.cartItems)
      .where(eq(schema.cartItems.id, id));
    
    return true; // Return true as the operation completed
  }

  async clearCart(sessionId: string): Promise<boolean> {
    await db.delete(schema.cartItems)
      .where(eq(schema.cartItems.sessionId, sessionId));
    
    return true;
  }

  // Orders
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    // Create order
    const [newOrder] = await db.insert(schema.orders)
      .values({ 
        ...order, 
        status: order.status || 'pending',
        createdAt: new Date() 
      })
      .returning();
    
    // Create order items
    for (const item of items) {
      await db.insert(schema.orderItems)
        .values({ 
          ...item, 
          quantity: item.quantity || 1,
          orderId: newOrder.id 
        });
    }
    
    return newOrder;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const order = await db.query.orders.findFirst({
      where: eq(schema.orders.id, id)
    });
    return order || undefined;
  }

  async getOrdersBySessionId(sessionId: string): Promise<Order[]> {
    const orders = await db.query.orders.findMany({
      where: eq(schema.orders.sessionId, sessionId)
    });
    return orders;
  }
}

export const storage = new DatabaseStorage();