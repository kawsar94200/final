import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertCartItemSchema, insertOrderSchema, insertOrderItemSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.get("/api/categories/:slug", async (req, res) => {
    const { slug } = req.params;
    const category = await storage.getCategoryBySlug(slug);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    res.json(category);
  });

  // Products
  app.get("/api/products", async (req, res) => {
    const querySchema = z.object({
      categoryId: z.string().optional().transform(val => val ? parseInt(val) : undefined),
      featured: z.string().optional().transform(val => val === "true"),
      flashDeal: z.string().optional().transform(val => val === "true"),
      limit: z.string().optional().transform(val => val ? parseInt(val) : undefined),
      offset: z.string().optional().transform(val => val ? parseInt(val) : undefined),
    });
    
    const options = querySchema.safeParse(req.query);
    
    if (!options.success) {
      return res.status(400).json({ message: "Invalid query parameters" });
    }
    
    const products = await storage.getProducts(options.data);
    res.json(products);
  });

  app.get("/api/products/:slug", async (req, res) => {
    const { slug } = req.params;
    const product = await storage.getProductBySlug(slug);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    res.json(product);
  });

  app.get("/api/products/category/:slug", async (req, res) => {
    const { slug } = req.params;
    const category = await storage.getCategoryBySlug(slug);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    const products = await storage.getProducts({ categoryId: category.id });
    res.json(products);
  });

  app.get("/api/search", async (req, res) => {
    const querySchema = z.object({
      q: z.string(),
    });
    
    const query = querySchema.safeParse(req.query);
    
    if (!query.success) {
      return res.status(400).json({ message: "Search query is required" });
    }
    
    const products = await storage.searchProducts(query.data.q);
    res.json(products);
  });

  // Banners
  app.get("/api/banners", async (req, res) => {
    const banners = await storage.getBanners();
    res.json(banners);
  });

  // Cart
  app.get("/api/cart", async (req, res) => {
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const cartItems = await storage.getCartItems(sessionId);
    
    // Get product details for each cart item
    const productIds = cartItems.map(item => item.productId);
    const products = await storage.getProductsByIds(productIds);
    
    const cartItemsWithProducts = cartItems.map(item => {
      const product = products.find(p => p.id === item.productId);
      return {
        ...item,
        product
      };
    });
    
    res.json(cartItemsWithProducts);
  });

  app.post("/api/cart", async (req, res) => {
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const cartItemData = { ...req.body, sessionId };
    const validatedData = insertCartItemSchema.safeParse(cartItemData);
    
    if (!validatedData.success) {
      return res.status(400).json({ message: "Invalid cart item data" });
    }
    
    // Check if product exists
    const product = await storage.getProductById(validatedData.data.productId);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    // Check stock
    if (product.stock < validatedData.data.quantity) {
      return res.status(400).json({ message: "Not enough stock available" });
    }
    
    const cartItem = await storage.createCartItem(validatedData.data);
    
    // Get product details
    const cartItemWithProduct = {
      ...cartItem,
      product
    };
    
    res.status(201).json(cartItemWithProduct);
  });

  app.put("/api/cart/:id", async (req, res) => {
    const { id } = req.params;
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const cartItemId = parseInt(id);
    const cartItem = await storage.getCartItem(cartItemId);
    
    if (!cartItem) {
      return res.status(404).json({ message: "Cart item not found" });
    }
    
    if (cartItem.sessionId !== sessionId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    const quantitySchema = z.object({
      quantity: z.number().int().positive(),
    });
    
    const validatedData = quantitySchema.safeParse(req.body);
    
    if (!validatedData.success) {
      return res.status(400).json({ message: "Invalid quantity" });
    }
    
    // Check product stock
    const product = await storage.getProductById(cartItem.productId);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    if (product.stock < validatedData.data.quantity) {
      return res.status(400).json({ message: "Not enough stock available" });
    }
    
    const updatedCartItem = await storage.updateCartItem(cartItemId, validatedData.data.quantity);
    
    // Get product details
    const cartItemWithProduct = {
      ...updatedCartItem,
      product
    };
    
    res.json(cartItemWithProduct);
  });

  app.delete("/api/cart/:id", async (req, res) => {
    const { id } = req.params;
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const cartItemId = parseInt(id);
    const cartItem = await storage.getCartItem(cartItemId);
    
    if (!cartItem) {
      return res.status(404).json({ message: "Cart item not found" });
    }
    
    if (cartItem.sessionId !== sessionId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    await storage.deleteCartItem(cartItemId);
    res.status(204).end();
  });

  app.delete("/api/cart", async (req, res) => {
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    await storage.clearCart(sessionId);
    res.status(204).end();
  });

  // Checkout
  app.post("/api/checkout", async (req, res) => {
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    // Validate order data
    const orderSchema = insertOrderSchema.extend({
      items: z.array(insertOrderItemSchema.omit({ orderId: true }))
    });
    
    const orderData = { ...req.body, sessionId };
    const validatedData = orderSchema.safeParse(orderData);
    
    if (!validatedData.success) {
      return res.status(400).json({ message: "Invalid order data" });
    }
    
    const { items, ...orderInfo } = validatedData.data;
    
    // Create order
    const order = await storage.createOrder(orderInfo, items);
    
    // Clear cart
    await storage.clearCart(sessionId);
    
    res.status(201).json(order);
  });

  app.get("/api/orders", async (req, res) => {
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const orders = await storage.getOrdersBySessionId(sessionId);
    res.json(orders);
  });

  app.get("/api/orders/:id", async (req, res) => {
    const { id } = req.params;
    const sessionId = req.headers["x-session-id"] as string;
    
    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" });
    }
    
    const orderId = parseInt(id);
    const order = await storage.getOrder(orderId);
    
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    
    if (order.sessionId !== sessionId) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    res.json(order);
  });

  const httpServer = createServer(app);
  return httpServer;
}
