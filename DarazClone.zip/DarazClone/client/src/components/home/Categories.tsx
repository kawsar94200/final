import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Category } from "@shared/schema";

export default function Categories() {
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"]
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded shadow mb-4 p-4">
        <h2 className="font-bold text-xl mb-4">CATEGORIES</h2>
        <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {Array(6).fill(0).map((_, index) => (
            <div key={index} className="text-center p-2 rounded">
              <Skeleton className="w-16 h-16 mx-auto rounded-full" />
              <Skeleton className="w-20 h-4 mt-2 mx-auto" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Map from category slug to image URL
  const categoryImages: Record<string, string> = {
    smartphones: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    laptops: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    tvs: "https://images.unsplash.com/photo-1600003263720-95b45a4035d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    "mens-fashion": "https://images.unsplash.com/photo-1578345218746-50a229b3d0f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    "womens-fashion": "https://images.unsplash.com/photo-1588117305388-c2631a279f82?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    "home-appliances": "https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
  };

  return (
    <div className="bg-white rounded shadow mb-4 p-4">
      <h2 className="font-bold text-xl mb-4">CATEGORIES</h2>
      <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {categories.map(category => (
          <Link 
            key={category.id} 
            href={`/category/${category.slug}`} 
            className="text-center hover:shadow-md transition-shadow p-2 rounded"
          >
            <img 
              src={categoryImages[category.slug] || "https://via.placeholder.com/100"} 
              alt={category.name} 
              className="w-16 h-16 object-contain mx-auto"
            />
            <p className="text-sm mt-2 text-dark-gray">{category.name}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
