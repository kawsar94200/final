import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Banner } from "@shared/schema";

export default function BannerCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: banners = [], isLoading } = useQuery<Banner[]>({
    queryKey: ["/api/banners"]
  });

  useEffect(() => {
    if (banners.length === 0) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [banners.length]);

  const nextSlide = () => {
    if (banners.length === 0) return;
    setCurrentSlide((prev) => (prev + 1) % banners.length);
  };

  const prevSlide = () => {
    if (banners.length === 0) return;
    setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length);
  };
  
  if (isLoading) {
    return (
      <div className="banner-carousel relative overflow-hidden rounded mb-4">
        <Skeleton className="w-full h-full rounded" />
      </div>
    );
  }

  if (banners.length === 0) {
    return null;
  }

  return (
    <div className="banner-carousel relative overflow-hidden rounded mb-4">
      {banners.map((banner, index) => (
        <div 
          key={banner.id} 
          className={`absolute top-0 left-0 w-full h-full transition-opacity duration-500 ${index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
        >
          <Link href={banner.url}>
            <img 
              src={banner.image} 
              alt={banner.alt} 
              className="w-full h-full object-cover"
            />
          </Link>
        </div>
      ))}
      
      {/* Carousel Controls */}
      <button 
        className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white/70 p-2 rounded-r z-20"
        onClick={prevSlide}
      >
        <i className="fa-solid fa-chevron-left text-secondary"></i>
      </button>
      <button 
        className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white/70 p-2 rounded-l z-20"
        onClick={nextSlide}
      >
        <i className="fa-solid fa-chevron-right text-secondary"></i>
      </button>
      
      {/* Indicators */}
      <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
        {banners.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-8 bg-white rounded-full ${
              index === currentSlide ? 'opacity-100' : 'opacity-50'
            }`}
            onClick={() => setCurrentSlide(index)}
          ></button>
        ))}
      </div>
    </div>
  );
}
