import { Link, useLocation } from "wouter";

export default function MobileNavbar() {
  const [location] = useLocation();

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_5px_rgba(0,0,0,0.1)] py-2 z-10">
      <div className="flex justify-around">
        <Link href="/" className="text-center">
          <i className={`fa-solid fa-house text-xl ${location === '/' ? 'text-secondary' : 'text-dark-gray'}`}></i>
          <span className="block text-xs mt-1">Home</span>
        </Link>
        <Link href="#" className="text-center">
          <i className="fa-solid fa-list text-dark-gray text-xl"></i>
          <span className="block text-xs mt-1">Categories</span>
        </Link>
        <Link href="/cart" className="text-center">
          <i className={`fa-solid fa-cart-shopping text-xl ${location === '/cart' ? 'text-secondary' : 'text-dark-gray'}`}></i>
          <span className="block text-xs mt-1">Cart</span>
        </Link>
        <Link href="#" className="text-center">
          <i className="fa-solid fa-message text-dark-gray text-xl"></i>
          <span className="block text-xs mt-1">Messages</span>
        </Link>
        <Link href="#" className="text-center">
          <i className="fa-solid fa-user text-dark-gray text-xl"></i>
          <span className="block text-xs mt-1">Account</span>
        </Link>
      </div>
    </div>
  );
}
