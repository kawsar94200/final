import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Category } from "@shared/schema";

export default function CategorySidebar() {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"]
  });

  if (isLoading) {
    return (
      <div className="hidden lg:block lg:col-span-1">
        <div className="bg-white rounded shadow category-menu">
          <h3 className="font-medium text-text-black p-4 border-b">Categories</h3>
          <ul>
            {Array(8).fill(0).map((_, index) => (
              <li key={index} className="border-b p-3">
                <Skeleton className="h-6 w-full" />
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  return (
    <div className="hidden lg:block lg:col-span-1">
      <div className="bg-white rounded shadow category-menu">
        <h3 className="font-medium text-text-black p-4 border-b">Categories</h3>
        <ul>
          {categories?.map((category) => (
            <li key={category.id} className="border-b hover:bg-neutral">
              <Link 
                href={`/category/${category.slug}`} 
                className="flex items-center p-3 text-sm text-dark-gray"
              >
                <i className={`fa-solid ${category.icon} w-6`}></i>
                <span>{category.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
