import { Link } from "wouter";
import { Product } from "@shared/schema";
import { formatCurrency } from "@/lib/utils";
import StarRating from "./StarRating";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const discountPercentage = product.discountPercentage || 0;
  
  return (
    <Link href={`/product/${product.slug}`} className="block">
      <div className="border rounded hover:shadow-md transition-shadow">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-40 object-contain p-2"
        />
        <div className="p-2">
          <h3 className="text-sm text-text-black font-medium ellipsis-2">
            {product.name}
          </h3>
          <div className="flex space-x-1 mt-1">
            <span className="text-secondary font-bold">{formatCurrency(Number(product.price))}</span>
            {product.originalPrice && Number(product.originalPrice) > Number(product.price) && (
              <span className="text-light-gray line-through text-xs">
                {formatCurrency(Number(product.originalPrice))}
              </span>
            )}
          </div>
          <div className="flex items-center text-xs mt-1">
            <StarRating rating={Number(product.rating)} />
            <span className="text-light-gray ml-1">({product.reviewCount})</span>
          </div>
          {discountPercentage > 0 && (
            <div className="mt-2">
              <div className="bg-red-100 text-red-600 text-xs px-1 inline-block rounded">
                -{discountPercentage}%
              </div>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
