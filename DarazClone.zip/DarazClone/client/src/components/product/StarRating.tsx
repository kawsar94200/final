interface StarRatingProps {
  rating: number;
}

export default function StarRating({ rating }: StarRatingProps) {
  // Round to nearest half star
  const roundedRating = Math.round(rating * 2) / 2;
  
  const stars = [];
  
  // Full stars
  for (let i = 1; i <= Math.floor(roundedRating); i++) {
    stars.push(<i key={`full-${i}`} className="fa-solid fa-star"></i>);
  }
  
  // Half star
  if (roundedRating % 1 !== 0) {
    stars.push(<i key="half" className="fa-solid fa-star-half-stroke"></i>);
  }
  
  // Empty stars
  for (let i = Math.ceil(roundedRating); i < 5; i++) {
    stars.push(<i key={`empty-${i}`} className="fa-regular fa-star"></i>);
  }

  return (
    <div className="flex text-yellow-400">
      {stars}
    </div>
  );
}
