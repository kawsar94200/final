import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { formatCurrency, getSessionId } from "@/lib/utils";
import { Product } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CartItemProps {
  id: number;
  product: Product;
  quantity: number;
}

export default function CartItem({ id, product, quantity }: CartItemProps) {
  const [itemQuantity, setItemQuantity] = useState(quantity);
  const { toast } = useToast();
  
  // Update cart item quantity
  const { mutate: updateQuantity, isPending: isUpdating } = useMutation({
    mutationFn: async (newQuantity: number) => {
      return await apiRequest("PUT", `/api/cart/${id}`, { quantity: newQuantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error) => {
      setItemQuantity(quantity); // Reset to previous quantity
      toast({
        title: "Error",
        description: error.message || "Failed to update quantity",
        variant: "destructive",
      });
    }
  });
  
  // Remove item from cart
  const { mutate: removeItem, isPending: isRemoving } = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/cart/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Item removed",
        description: "Item has been removed from your cart",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove item",
        variant: "destructive",
      });
    }
  });
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (value > 0 && value <= product.stock) {
      setItemQuantity(value);
      updateQuantity(value);
    }
  };
  
  const handleIncrement = () => {
    if (itemQuantity < product.stock) {
      const newQuantity = itemQuantity + 1;
      setItemQuantity(newQuantity);
      updateQuantity(newQuantity);
    }
  };
  
  const handleDecrement = () => {
    if (itemQuantity > 1) {
      const newQuantity = itemQuantity - 1;
      setItemQuantity(newQuantity);
      updateQuantity(newQuantity);
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row items-start border-b py-4">
      <div className="md:w-1/4 mb-4 md:mb-0">
        <Link href={`/product/${product.slug}`}>
          <img src={product.image} alt={product.name} className="w-32 h-32 object-contain mx-auto" />
        </Link>
      </div>
      <div className="md:w-3/4 space-y-2">
        <Link href={`/product/${product.slug}`} className="hover:text-secondary">
          <h3 className="font-medium text-lg">{product.name}</h3>
        </Link>
        <div className="text-secondary font-bold text-lg">
          {formatCurrency(Number(product.price))}
          {product.originalPrice && Number(product.originalPrice) > Number(product.price) && (
            <span className="text-light-gray line-through text-sm ml-2">
              {formatCurrency(Number(product.originalPrice))}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-dark-gray">Quantity:</span>
          <div className="flex items-center border rounded">
            <Button 
              type="button" 
              variant="ghost" 
              size="sm" 
              onClick={handleDecrement}
              disabled={itemQuantity <= 1 || isUpdating}
              className="px-2 py-0 h-8"
            >
              <i className="fa-solid fa-minus"></i>
            </Button>
            <Input
              type="number"
              min="1"
              max={product.stock}
              value={itemQuantity}
              onChange={handleQuantityChange}
              disabled={isUpdating}
              className="w-12 text-center border-0 p-0 h-8"
            />
            <Button 
              type="button" 
              variant="ghost" 
              size="sm" 
              onClick={handleIncrement}
              disabled={itemQuantity >= product.stock || isUpdating}
              className="px-2 py-0 h-8"
            >
              <i className="fa-solid fa-plus"></i>
            </Button>
          </div>
        </div>
        <div className="pt-2">
          <Button 
            type="button" 
            variant="ghost" 
            onClick={() => removeItem()}
            disabled={isRemoving}
            className="text-red-500 hover:text-red-700 hover:bg-red-50 px-0"
          >
            <i className="fa-solid fa-trash-alt mr-2"></i>
            Remove
          </Button>
        </div>
      </div>
    </div>
  );
}
