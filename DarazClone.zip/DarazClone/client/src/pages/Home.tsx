import { Helmet } from "react-helmet-async";
import { useQuery } from "@tanstack/react-query";
import CategorySidebar from "@/components/layout/CategorySidebar";
import BannerCarousel from "@/components/home/BannerCarousel";
import FlashSale from "@/components/home/FlashSale";
import Categories from "@/components/home/Categories";
import JustForYou from "@/components/home/JustForYou";
import { Category } from "@shared/schema";

export default function Home() {
  // Pre-fetch categories for sidebar
  useQuery<Category[]>({
    queryKey: ["/api/categories"]
  });
  
  return (
    <>
      <Helmet>
        <title>KAWSAR - Online Shopping Mall</title>
        <meta name="description" content="KAWSAR - The biggest online shopping mall in Bangladesh. Shop online for electronics, clothing, home appliances, and more with great deals and discounts." />
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <CategorySidebar />
        
        <div className="lg:col-span-4">
          <BannerCarousel />
          <FlashSale />
          <Categories />
          <JustForYou />
        </div>
      </div>
    </>
  );
}
