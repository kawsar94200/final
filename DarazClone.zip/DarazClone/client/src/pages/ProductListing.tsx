import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery } from "@tanstack/react-query";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import CategorySidebar from "@/components/layout/CategorySidebar";
import ProductCard from "@/components/product/ProductCard";
import { Product, Category } from "@shared/schema";

export default function ProductListing() {
  const { slug } = useParams();
  const [sortBy, setSortBy] = useState("default");
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  
  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/${slug}`]
  });
  
  const { data: products = [], isLoading: isProductsLoading } = useQuery<Product[]>({
    queryKey: [`/api/products/category/${slug}`],
    enabled: !!slug
  });
  
  // Sort products based on selected option
  useEffect(() => {
    if (!products) return;
    
    let sorted = [...products];
    
    switch (sortBy) {
      case "price-asc":
        sorted.sort((a, b) => Number(a.price) - Number(b.price));
        break;
      case "price-desc":
        sorted.sort((a, b) => Number(b.price) - Number(a.price));
        break;
      case "newest":
        // In this mock, we don't have a date field, so keep default order
        break;
      case "popularity":
        sorted.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      default:
        // Default sorting, keep as is
        break;
    }
    
    setFilteredProducts(sorted);
  }, [products, sortBy]);
  
  const isLoading = isCategoryLoading || isProductsLoading;
  
  return (
    <>
      <Helmet>
        <title>{category ? `${category.name} - KAWSAR` : "Category - KAWSAR"}</title>
        <meta name="description" content={`Browse our collection of ${category?.name || "products"} at the best prices. Free shipping, cash on delivery, and easy returns.`} />
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <CategorySidebar />
        
        <div className="lg:col-span-4">
          {/* Category Title & Sorting */}
          <div className="bg-white rounded shadow p-4 mb-4 flex justify-between items-center">
            <h1 className="text-xl font-bold">
              {isLoading ? (
                <Skeleton className="h-8 w-40" />
              ) : (
                category?.name || "Category"
              )}
            </h1>
            
            <div className="flex items-center">
              <span className="text-sm mr-2 text-dark-gray">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Default" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="popularity">Popularity</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="bg-white rounded shadow p-4">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array(8).fill(0).map((_, index) => (
                  <div key={index} className="border rounded">
                    <Skeleton className="w-full h-40" />
                    <div className="p-2">
                      <Skeleton className="w-full h-4 mt-2" />
                      <Skeleton className="w-2/3 h-4 mt-2" />
                      <Skeleton className="w-1/2 h-4 mt-2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="py-8 text-center">
                <i className="fa-solid fa-box-open text-4xl text-gray-300 mb-4"></i>
                <p className="text-dark-gray">No products found in this category</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
