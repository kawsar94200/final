import { useState } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage 
} from "@/components/ui/form";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, getSessionId } from "@/lib/utils";
import CheckoutSteps from "@/components/checkout/CheckoutSteps";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Product } from "@shared/schema";

interface ExtendedCartItem {
  id: number;
  productId: number;
  sessionId: string;
  quantity: number;
  product: Product;
}

const addressFormSchema = z.object({
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  phone: z.string().min(11, "Phone number must be at least 11 digits"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  city: z.string().min(2, "City is required"),
  area: z.string().min(2, "Area is required"),
  zipCode: z.string().min(4, "Zip code must be at least 4 digits"),
});

const paymentFormSchema = z.object({
  paymentMethod: z.enum(["cod", "bkash", "card"]),
  cardNumber: z.string().optional(),
  cardExpiry: z.string().optional(),
  cardCvv: z.string().optional(),
  bkashNumber: z.string().optional(),
});

type AddressFormValues = z.infer<typeof addressFormSchema>;
type PaymentFormValues = z.infer<typeof paymentFormSchema>;

export default function Checkout() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [addressData, setAddressData] = useState<AddressFormValues | null>(null);
  
  // Form for address step
  const addressForm = useForm<AddressFormValues>({
    resolver: zodResolver(addressFormSchema),
    defaultValues: {
      fullName: "",
      phone: "",
      address: "",
      city: "",
      area: "",
      zipCode: "",
    },
  });
  
  // Form for payment step
  const paymentForm = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      paymentMethod: "cod",
    },
  });
  
  // Get cart items
  const { data: cartItems = [], isLoading } = useQuery<ExtendedCartItem[]>({
    queryKey: ["/api/cart"],
    headers: {
      "x-session-id": getSessionId(),
    },
  });
  
  // Calculate cart summary
  const cartSummary = {
    subtotal: cartItems.reduce((sum, item) => sum + (Number(item.product.price) * item.quantity), 0),
    shipping: cartItems.length > 0 ? 50 : 0, // 50 BDT shipping fee
    get total() { return this.subtotal + this.shipping; }
  };
  
  // Place order mutation
  const { mutate: placeOrder, isPending: isPlacingOrder } = useMutation({
    mutationFn: async (data: { paymentMethod: string, shippingAddress: any }) => {
      const orderItems = cartItems.map(item => ({
        productId: item.productId,
        name: item.product.name,
        price: item.product.price,
        quantity: item.quantity,
      }));
      
      return await apiRequest("POST", "/api/checkout", {
        totalAmount: cartSummary.total,
        shippingAddress: data.shippingAddress,
        paymentMethod: data.paymentMethod,
        items: orderItems,
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      navigate(`/order-confirmation/${data.id}`);
      toast({
        title: "Order placed successfully",
        description: "Your order has been placed and will be processed soon.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to place order",
        variant: "destructive",
      });
    }
  });
  
  const onAddressSubmit = (data: AddressFormValues) => {
    setAddressData(data);
    setStep(2);
  };
  
  const onPaymentSubmit = (data: PaymentFormValues) => {
    if (!addressData) {
      toast({
        title: "Error",
        description: "Please complete the address step first",
        variant: "destructive",
      });
      return;
    }
    
    placeOrder({
      paymentMethod: data.paymentMethod,
      shippingAddress: addressData,
    });
  };
  
  // Watch payment method to conditionally show fields
  const watchPaymentMethod = paymentForm.watch("paymentMethod");
  
  if (isLoading) {
    return (
      <div className="bg-white rounded shadow p-6">
        <Skeleton className="h-8 w-40 mb-6" />
        <Skeleton className="h-4 w-full mb-4" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Skeleton className="h-60 w-full" />
          </div>
          <div className="lg:col-span-1">
            <Skeleton className="h-60 w-full" />
          </div>
        </div>
      </div>
    );
  }
  
  if (cartItems.length === 0) {
    return (
      <div className="bg-white rounded shadow p-6 text-center py-12">
        <i className="fa-solid fa-shopping-cart text-gray-300 text-5xl mb-4"></i>
        <h1 className="text-2xl font-bold mb-2">Your cart is empty</h1>
        <p className="text-dark-gray mb-6">Please add some products to your cart before proceeding to checkout.</p>
        <Button onClick={() => navigate("/")}>Continue Shopping</Button>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Checkout - KAWSAR</title>
        <meta name="description" content="Complete your purchase from KAWSAR. Provide your shipping and payment details to place your order." />
      </Helmet>
      
      <div className="bg-white rounded shadow p-6">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>
        
        <CheckoutSteps currentStep={step} />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {step === 1 && (
              <Card>
                <CardHeader>
                  <CardTitle>Shipping Address</CardTitle>
                  <CardDescription>Please enter your shipping information</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...addressForm}>
                    <form onSubmit={addressForm.handleSubmit(onAddressSubmit)} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={addressForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your full name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addressForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="Your phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={addressForm.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Your full address" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={addressForm.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>City</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select city" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="dhaka">Dhaka</SelectItem>
                                  <SelectItem value="chittagong">Chittagong</SelectItem>
                                  <SelectItem value="khulna">Khulna</SelectItem>
                                  <SelectItem value="rajshahi">Rajshahi</SelectItem>
                                  <SelectItem value="sylhet">Sylhet</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addressForm.control}
                          name="area"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Area</FormLabel>
                              <FormControl>
                                <Input placeholder="Your area" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={addressForm.control}
                          name="zipCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Zip Code</FormLabel>
                              <FormControl>
                                <Input placeholder="Zip code" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="flex justify-end mt-6">
                        <Button type="submit">
                          Continue to Payment
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            )}
            
            {step === 2 && (
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                  <CardDescription>Choose your preferred payment option</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...paymentForm}>
                    <form onSubmit={paymentForm.handleSubmit(onPaymentSubmit)} className="space-y-6">
                      <FormField
                        control={paymentForm.control}
                        name="paymentMethod"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>Payment Method</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex flex-col space-y-1"
                              >
                                <FormItem className="flex items-center space-x-3 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="cod" />
                                  </FormControl>
                                  <FormLabel className="font-normal mt-0 flex items-center">
                                    <img src="https://icms-image.slatic.net/images/ims-web/9a08515e-f7e8-461e-a6b3-ae003997dbf5.png" alt="Cash on Delivery" className="h-6 mr-2" />
                                    Cash on Delivery
                                  </FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-3 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="bkash" />
                                  </FormControl>
                                  <FormLabel className="font-normal mt-0 flex items-center">
                                    <img src="https://icms-image.slatic.net/images/ims-web/6cb39cbf-6430-4b34-8da2-d415586717f3.png" alt="bKash" className="h-6 mr-2" />
                                    bKash
                                  </FormLabel>
                                </FormItem>
                                <FormItem className="flex items-center space-x-3 space-y-0">
                                  <FormControl>
                                    <RadioGroupItem value="card" />
                                  </FormControl>
                                  <FormLabel className="font-normal mt-0 flex items-center">
                                    <img src="https://icms-image.slatic.net/images/ims-web/e0672529-f99e-462f-9ba6-8a33f33efa8a.png" alt="Credit/Debit Card" className="h-6 mr-2" />
                                    <img src="https://icms-image.slatic.net/images/ims-web/da9c572c-4dbf-4ecd-8e80-c5d7a0012950.png" alt="Mastercard" className="h-6 ml-1" />
                                    Credit/Debit Card
                                  </FormLabel>
                                </FormItem>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {watchPaymentMethod === "bkash" && (
                        <FormField
                          control={paymentForm.control}
                          name="bkashNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>bKash Number</FormLabel>
                              <FormControl>
                                <Input placeholder="Your bKash number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      {watchPaymentMethod === "card" && (
                        <>
                          <FormField
                            control={paymentForm.control}
                            name="cardNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Card Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="Card number" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={paymentForm.control}
                              name="cardExpiry"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Expiry Date</FormLabel>
                                  <FormControl>
                                    <Input placeholder="MM/YY" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={paymentForm.control}
                              name="cardCvv"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>CVV</FormLabel>
                                  <FormControl>
                                    <Input placeholder="CVV" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </>
                      )}
                      
                      <div className="flex justify-between mt-6">
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={() => setStep(1)}
                        >
                          Back to Address
                        </Button>
                        <Button 
                          type="submit"
                          disabled={isPlacingOrder}
                          className="bg-secondary hover:bg-secondary/90"
                        >
                          {isPlacingOrder ? "Processing..." : "Place Order"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {cartItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center pb-2 border-b">
                    <div className="flex items-center">
                      <img 
                        src={item.product.image} 
                        alt={item.product.name} 
                        className="w-12 h-12 object-contain mr-2"
                      />
                      <div>
                        <p className="text-sm font-medium line-clamp-1">{item.product.name}</p>
                        <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                      </div>
                    </div>
                    <p className="font-medium">{formatCurrency(Number(item.product.price) * item.quantity)}</p>
                  </div>
                ))}
                
                <div className="space-y-2 pt-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>{formatCurrency(cartSummary.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Shipping</span>
                    <span>{formatCurrency(cartSummary.shipping)}</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span className="text-secondary">{formatCurrency(cartSummary.total)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
